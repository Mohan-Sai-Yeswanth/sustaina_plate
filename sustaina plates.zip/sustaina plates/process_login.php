<?php
// Simulated user data (replace with database access)
$validUser = [
    'username' => 'user123',
    'password' => 'password123',
];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get user input
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the provided username and password match the valid user data
    if ($username === $validUser['username'] && $password === $validUser['password']) {
        // Successful login, redirect to a dashboard or home page
        header('Location: dashboard.php'); // Replace with the actual dashboard page URL
        exit();
    } else {
        // Invalid login, display an error message
        $error = 'Invalid username or password.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EcoEats</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>
    <div class="login-container">
        <h1>Login to EcoEats</h1>
        <form id="loginForm" action="process_login.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Login</button>
        </form>
        <?php if (isset($error)) : ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <p>Don't have an account? <a href="signup.html">Sign up</a></p>
    </div>
</body>
</html>
