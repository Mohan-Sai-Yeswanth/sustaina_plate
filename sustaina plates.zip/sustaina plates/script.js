// JavaScript for EcoEats Website

// Function to validate the signup form
function validateForm() {
    var name = document.forms["signupForm"]["name"].value;
    var email = document.forms["signupForm"]["email"].value;

    if (name === "") {
        alert("Name must be filled out");
        return false;
    }

    if (email === "") {
        alert("Email must be filled out");
        return false;
    }

    // Additional validation can be added as needed

    return true;
}

// Add event listener for form submission
document.addEventListener("DOMContentLoaded", function() {
    var form = document.getElementById("signupForm");
    if (form) {
        form.addEventListener("submit", function(event) {
            if (!validateForm()) {
                event.preventDefault();
            }
        });
    }
});
// Accessing the "Get Started" button by its class
var getStartedButton = document.querySelector('.cta-button');

// Adding a click event listener to the button
getStartedButton.addEventListener('click', function() {
    // Redirect to the login page
    window.location.href = 'login.html'; // Replace 'login.html' with your actual login page URL
});

